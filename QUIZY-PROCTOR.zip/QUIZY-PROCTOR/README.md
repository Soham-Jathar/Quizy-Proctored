# Quizy-proctor
A secure web-based quiz platform with proctoring features like camera monitoring, mic noise detection, and tab-switch tracking to prevent cheating during online exams.
